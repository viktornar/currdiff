package com.concretepage;


public interface StudentService {
   String getStudent(Integer id);
}
